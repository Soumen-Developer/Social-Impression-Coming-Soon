<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require __DIR__ . '/vendor/autoload.php';
} else {
    require __DIR__ . '/PHPMailer/src/Exception.php';
    require __DIR__ . '/PHPMailer/src/PHPMailer.php';
    require __DIR__ . '/PHPMailer/src/SMTP.php';
}

// Debug logger (must be defined before loadEnv)
$logFile = __DIR__ . '/debug_log.txt';
function logStep($msg)
{
    global $logFile;
    file_put_contents($logFile, date('[Y-m-d H:i:s] ') . $msg . "\n", FILE_APPEND);
}

// ---------------------------------------------------
// Lightweight .env loader (no Composer dependency)
// ---------------------------------------------------
function loadEnv($path)
{
    if (!file_exists($path)) {
        logStep(".env file NOT found at: $path");
        return;
    }
    logStep(".env file found at: $path");
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#')
            continue;
        if (strpos($line, '=') === false)
            continue;
        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        // Strip surrounding quotes if present
        if (
            (str_starts_with($value, '"') && str_ends_with($value, '"')) ||
            (str_starts_with($value, "'") && str_ends_with($value, "'"))
        ) {
            $value = substr($value, 1, -1);
        }
        if (!array_key_exists($key, $_ENV)) {
            $_ENV[$key] = $value;
            putenv("$key=$value");
        }
    }
}

// Load .env — check same directory first (Hostinger), then parent (local dev)
if (file_exists(__DIR__ . '/.env')) {
    loadEnv(__DIR__ . '/.env');
} else {
    loadEnv(__DIR__ . '/../.env');
}
logStep("SMTP_USER loaded: " . (getenv('SMTP_USER') ?: '(empty)'));
logStep("SMTP_PASSWORD loaded: " . (getenv('SMTP_PASSWORD') ? '***set (' . strlen(getenv('SMTP_PASSWORD')) . ' chars)***' : '(empty)'));

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 0);

// ---------------------------------------------------
// Get real client IP (handles proxies & Cloudflare)
// ---------------------------------------------------
function getUserIP()
{
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

logStep("Script started");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rawInput = file_get_contents("php://input");
    logStep("Raw Input: " . $rawInput);

    $input = json_decode($rawInput, true);

    $name = htmlspecialchars(strip_tags($input['name'] ?? ''));
    $email = filter_var($input['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(strip_tags($input['phone'] ?? ''));

    // Honeypot spam protection — hidden "company" field
    if (!empty($input['company'])) {
        logStep("SPAM DETECTED: honeypot field filled. Rejecting.");
        header('Content-Type: application/json');
        echo json_encode(["success" => true, "message" => "Thank you!"]);
        exit;
    }

    if (empty($name)) {
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "message" => "Name is required"]);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "message" => "Invalid email format"]);
        exit;
    }
    if (empty($phone)) {
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "message" => "Phone number is required"]);
        exit;
    }

    logStep("Validation passed. Starting async response.");

    // Ignore user abort and set time limit for background work
    ignore_user_abort(true);
    if (function_exists('set_time_limit')) {
        @set_time_limit(300); // Give the script 5 minutes to finish in background
    }

    // LiteSpeed specific header to ignore abort
    header('X-LiteSpeed-Ignore-Abort: On');

    // Buffer the response
    ob_start();
    echo json_encode(["success" => true, "message" => "Thank you! We'll be in touch soon."]);
    $size = ob_get_length();

    // Explicitly calculate length and send headers to force connection close
    header('Content-Type: application/json');
    header("Content-Length: $size");
    header("Connection: close");

    // Flush all output buffers safely
    while (ob_get_level() > 0) {
        ob_end_flush();
    }
    flush();

    // Close session to prevent write locks during background processing
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }

    logStep("Response sent to client. Proceeding in background.");

    // ---------------------------------------------------
    // GEO DATA — received from frontend (silently fetched in browser)
    // Browser always has the correct public IP, no localhost issues.
    // ---------------------------------------------------
    $country = htmlspecialchars(strip_tags($input['country'] ?? ''));
    $city = htmlspecialchars(strip_tags($input['city'] ?? ''));
    $region = htmlspecialchars(strip_tags($input['region'] ?? ''));
    $ip = htmlspecialchars(strip_tags($input['ip'] ?? getUserIP()));
    $geoRaw = $input['geoRaw'] ?? [];  // Full ipapi.co response — forwarded as-is
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $referrer = $_SERVER['HTTP_REFERER'] ?? '';

    logStep("Geo from frontend — Country: $country, City: $city, Region: $region, IP: $ip");

    // SMTP Settings (from .env)
    $smtpUser = getenv('SMTP_USER') ?: 'connect@socialimpression.co';
    $smtpPassword = getenv('SMTP_PASSWORD') ?: '';
    $smtpHost = getenv('SMTP_HOST') ?: 'smtp.gmail.com';
    $smtpPort = (int) (getenv('SMTP_PORT') ?: 587);

    // Log all config for debugging
    logStep("=== SMTP CONFIG ===");
    logStep("  Host: $smtpHost");
    logStep("  Port: $smtpPort");
    logStep("  User: $smtpUser");
    logStep("  Password: " . ($smtpPassword ? str_repeat('*', strlen($smtpPassword)) . " (" . strlen($smtpPassword) . " chars)" : "(EMPTY!)"));
    logStep("  PHP Version: " . phpversion());
    logStep("  OpenSSL: " . (extension_loaded('openssl') ? 'YES (' . OPENSSL_VERSION_TEXT . ')' : 'NOT LOADED!'));
    logStep("  Server: " . php_sapi_name());
    logStep("===================");

    $brochurePath = __DIR__ . '/brochure/The Artist Handbook.pdf';
    $headerPath = __DIR__ . '/assets/mail_header.png';

    logStep("Brochure exists: " . (file_exists($brochurePath) ? 'YES (' . filesize($brochurePath) . ' bytes)' : 'NO!'));
    logStep("Header image exists: " . (file_exists($headerPath) ? 'YES (' . filesize($headerPath) . ' bytes)' : 'NO!'));

    try {

        // -------------------------------------------------------
        // GOOGLE SHEETS FIRST — runs before email because
        // LiteSpeed may kill the process during the slow email
        // send (30s+ with 3MB attachment). Sheets only takes ~4s.
        // -------------------------------------------------------
        logStep("[STEP 1] Starting Google Sheets logging...");
        $sheetUrl = getenv('GOOGLE_SHEET_URL') ?: '';
        logStep("  Sheet URL: " . ($sheetUrl ? substr($sheetUrl, 0, 60) . '...' : '(EMPTY!)'));
        $sheetData = json_encode([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'country' => $country,
            'meeting' => '',
            'source' => 'Website Waitlist',
            'ip' => $ip,
            'city' => $city,
            'region' => $region,
            'userAgent' => $userAgent,
            'referrer' => $referrer,
            'geoRaw' => $geoRaw,
        ]);

        logStep("  Sheet payload: " . $sheetData);

        // Retry Google Sheets up to 2 times
        $sheetSuccess = false;
        for ($sheetAttempt = 1; $sheetAttempt <= 2; $sheetAttempt++) {
            $ch = curl_init($sheetUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $sheetData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            $sheetResponse = curl_exec($ch);
            $curlError = curl_error($ch);
            curl_close($ch);

            if (!$curlError) {
                logStep("Google Sheets Response: " . $sheetResponse);
                $sheetSuccess = true;
                break;
            }
            logStep("Google Sheets attempt $sheetAttempt error: " . $curlError);
            if ($sheetAttempt < 2)
                sleep(2);
        }
        if (!$sheetSuccess) {
            logStep("WARNING: Google Sheets logging failed after retries.");
        }

        // -------------------------------------------------------
        // EMAIL: Thank-You to User (with brochure)
        // Runs after Sheets so data is saved even if email is slow.
        // -------------------------------------------------------
        logStep("[STEP 2] Creating PHPMailer instance...");
        $mailUser = new PHPMailer(true);
        $mailUser->isSMTP();
        logStep("[STEP 3] Configuring SMTP connection...");
        $mailUser->Host = $smtpHost;
        $mailUser->SMTPAuth = true;
        $mailUser->Username = $smtpUser;
        $mailUser->Password = $smtpPassword;
        $mailUser->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mailUser->Port = $smtpPort;

        // SMTP Debug — set to 2 for full conversation, 0 for production
        $mailUser->SMTPDebug = 0;
        $mailUser->Debugoutput = function ($str, $level) {
            logStep("  SMTP[$level]: " . trim($str));
        };

        $mailUser->SMTPKeepAlive = true;
        $mailUser->Timeout = 30;
        $mailUser->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        logStep("[STEP 4] SMTP configured. Setting from/to...");

        $mailUser->setFrom($smtpUser, 'Social Impression');
        $mailUser->addAddress($email, $name);
        logStep("[STEP 5] From: $smtpUser | To: $email");

        if (file_exists($headerPath)) {
            $mailUser->addEmbeddedImage($headerPath, 'mail_header');
            logStep("Header image embedded.");
        }

        if (file_exists($brochurePath)) {
            $mailUser->addAttachment($brochurePath, 'The Artist Handbook.pdf');
            logStep("Brochure attached.");
        } else {
            logStep("Brochure NOT found at: " . $brochurePath);
        }

        logStep("[STEP 6] Setting email subject and HTML body...");
        $mailUser->isHTML(true);
        $mailUser->Subject = "Welcome to Social Impression, $name!";

        // HTML Body
        // <div style='background: linear-gradient(135deg, #0f0f0f 0%, #1a1a2e 100%); padding: 0; text-align: center; border-radius: 8px 8px 0 0; overflow: hidden;'>
        // <img src='cid:mail_header' alt='Social Impression' style='width: 100%; max-width: 600px; display: block; border-radius: 8px 8px 0 0;'>
        // <div style='padding: 20px 30px;'>
        //     <h1 style='color: #ffffff; margin: 0; font-size: 28px; letter-spacing: 3px;'>SOCIAL IMPRESSION</h1>
        //     <p style='color: rgba(255,255,255,0.6); margin: 10px 0 0; font-size: 14px;'>Your music deserves more.</p>
        // </div>

        $mailUser->Body = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;'>
                <div style='background: #0f0f0f; text-align: center; border-radius: 8px 8px 0 0; overflow: hidden; line-height: 0;'>
                    <img src='cid:mail_header' alt='Social Impression' style='width: 100%; max-width: 600px; display: block;'>
                </div>
                <div style='padding: 40px 30px; border: 1px solid #ddd; border-top: none; background: #ffffff;'>
                    <h2 style='color: #0f0f0f; margin-top: 0; font-size: 22px;'>You're on the list, $name! 🎉</h2>
                    <p style='font-size: 16px; line-height: 1.7; color: #444;'>
                        Thank you for joining the Social Impression waitlist. We know all the late nights, the endless edits. Your music deserves more, and that's exactly what we're building.
                    </p>
                    <p style='font-size: 16px; line-height: 1.7; color: #444;'>
                        We're building a platform to take your music to new highs, and you're among the first to know. We'll be in touch soon with your early access invite.
                    </p>
                    <div style='background: #f9f9f9; border-left: 4px solid #4646a4ff; padding: 16px 20px; margin: 30px 0; border-radius: 4px;'>
                        <p style='margin: 0; font-size: 15px; color: #333; font-weight: 600;'>🎵 Your exclusive gift is attached!</p>
                        <p style='margin: 8px 0 0; font-size: 14px; color: #666;'>We've included <strong>The Artist Handbook</strong>, a curated guide to help you navigate your music journey, as our thank-you for joining early.</p>
                    </div>
                    <div style='background: #f9f9f9; border-left: 4px solid #924e9bff; padding: 16px 20px; margin: 30px 0; border-radius: 4px;'>
                        <p style='margin: 0; font-size: 15px; color: #333; font-weight: 600;'>👉 Complete your Artist Enrollment Here:</p>
                        <p style='margin: 8px 0 0; font-size: 14px; color: #666;'><a href='https://forms.gle/Jv3AxNmGjhs2hChv9'>socialimpression.co/artist-enrollment</a></p>
                    </div>
                    <p style='font-size: 15px; line-height: 1.6; color: #444;'>Stay tuned!! Great things are coming your way.</p>
                    <p style='margin-top: 30px; font-size: 16px; color: #333;'>
                        With ❤️<br> 
                        <strong>The Social Impression Team</strong>
                    </p>
                </div>
                <div style='background-color: #f4f4f4; padding: 20px; text-align: center; font-size: 12px; color: #aaa; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px;'>
                    <p style='margin: 0;'>You received this because you signed up at socialimpression.co</p>
                    <p style='margin: 8px 0 0;'>&copy; " . date('Y') . " Social Impression. All rights reserved.</p>
                </div>
            </div>
        ";
        $mailUser->AltBody = "Welcome to Social Impression, $name!\n\nThank you for joining the waitlist. Please find The Artist Handbook attached.\n\nWith love,\nThe Social Impression Team";

        logStep("[STEP 7] Email body ready. Starting send with retry...");
        // Retry email up to 3 times to guarantee delivery
        $maxRetries = 3;
        $emailSent = false;
        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            try {
                $mailUser->send();
                $emailSent = true;
                logStep("User thank-you email sent to $email (attempt $attempt).");
                break;
            } catch (\Throwable $mailErr) {
                logStep("Email attempt $attempt failed: " . $mailErr->getMessage());
                if ($attempt < $maxRetries) {
                    sleep(2); // Wait 2s before retry
                    $mailUser->getSMTPInstance()->close(); // Reset connection
                }
            }
        }
        if (!$emailSent) {
            logStep("CRITICAL: All $maxRetries email attempts failed for $email.");
        }

        logStep("Background processing complete.");

    } catch (\Throwable $e) {
        logStep("Fatal Error: " . $e->getMessage());
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Server Error: " . $e->getMessage()]);
    }

} else {
    header('Content-Type: application/json');
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
}
?>